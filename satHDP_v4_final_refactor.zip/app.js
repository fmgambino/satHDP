const DEFAULT_DAMAGE_TYPES = {
  cano_roto: { label: 'Caño roto', emoji: '💧', color: '#38bdf8', active: true },
  falta_asfalto: { label: 'Falta asfalto', emoji: '🛣️', color: '#94a3b8', active: true },
  bache: { label: 'Bache', emoji: '🕳️', color: '#f59e0b', active: true },
  poste_caido: { label: 'Poste caído', emoji: '⚡', color: '#facc15', active: true },
  arbol_caido: { label: 'Árbol caído', emoji: '🌳', color: '#22c55e', active: true }
};

let DAMAGE_TYPES = { ...DEFAULT_DAMAGE_TYPES };
const STATUS = { pending: 'Pendiente', analysis: 'En análisis', approved: 'Aprobado', rejected: 'Rechazado' };
let supabaseClient, map, selectedMarker, chart, allReports = [], markers = [], deferredPrompt = null, googleMapsPromise = null;
const $ = (id) => document.getElementById(id);

function initSupabase() {
  const { SUPABASE_URL, SUPABASE_ANON_KEY } = window.APP_CONFIG || {};
  supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}

function showMapError(title, message) {
  const mapEl = $('map');
  if (mapEl) mapEl.innerHTML = `<div class="map-error"><strong>${title}</strong><p>${message}</p></div>`;
  Swal.fire(title, message, 'error');
}

function loadGoogleMaps() {
  const key = window.APP_CONFIG?.GOOGLE_MAPS_API_KEY;
  if (!key || key.includes('TU_GOOGLE')) {
    showMapError('Falta configurar Google Maps', 'Abrí config.js y cargá GOOGLE_MAPS_API_KEY con una clave válida.');
    return Promise.reject(new Error('Missing Google Maps API key'));
  }
  if (window.google?.maps?.importLibrary) return Promise.resolve();
  if (googleMapsPromise) return googleMapsPromise;

  googleMapsPromise = new Promise((resolve, reject) => {
    window.__satHDPGoogleReady = () => resolve();
    const oldScript = document.getElementById('googleMapsScript');
    if (oldScript) oldScript.remove();

    const script = document.createElement('script');
    script.id = 'googleMapsScript';
    script.async = true;
    script.defer = true;
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(key)}&libraries=places&loading=async&callback=__satHDPGoogleReady`;
    script.onerror = () => {
      const msg = 'No se pudo cargar Google Maps. Revisá que Maps JavaScript API y Places API estén habilitadas y que el referer autorizado incluya https://fmgambino.github.io/* y https://fmgambino.github.io/satHDP/*.';
      showMapError('Google Maps no cargó', msg);
      reject(new Error(msg));
    };
    document.head.appendChild(script);
  });
  return googleMapsPromise;
}

async function initMap() {
  await loadGoogleMaps();
  const { Map } = await google.maps.importLibrary('maps');
  map = new Map($('map'), {
    center: window.APP_CONFIG.MAP_CENTER,
    zoom: window.APP_CONFIG.MAP_ZOOM,
    mapTypeControl: false,
    streetViewControl: false,
    fullscreenControl: true,
    styles: document.documentElement.dataset.theme === 'dark' ? darkMapStyle : []
  });
  map.addListener('click', (e) => setSelectedLocation(e.latLng.lat(), e.latLng.lng()));
  await initGoogleAutocomplete();
  await loadDamageTypes();
  await loadReports();
  initRealtime();
}

async function initGoogleAutocomplete() {
  try {
    const places = await google.maps.importLibrary('places');
    if (places.PlaceAutocompleteElement) {
      createPlaceAutocompleteElement('searchHost', 'Buscar dirección, barrio, plaza...', false);
      createPlaceAutocompleteElement('addressHost', 'Buscar dirección del reclamo...', true);
      return;
    }
  } catch (err) {
    console.warn('PlaceAutocompleteElement no disponible, se usa fallback legacy.', err);
  }
  createLegacyAutocomplete('searchHost', 'searchInputFallback', false);
  createLegacyAutocomplete('addressHost', 'addressInputFallback', true);
}

function createPlaceAutocompleteElement(hostId, placeholder, fillAddress) {
  const host = $(hostId);
  host.innerHTML = '';
  const el = new google.maps.places.PlaceAutocompleteElement();
  el.className = 'places-field';
  el.setAttribute('placeholder', placeholder);
  el.setAttribute('aria-label', placeholder);
  if (window.APP_CONFIG.PLACES_COUNTRY) el.includedRegionCodes = [window.APP_CONFIG.PLACES_COUNTRY];
  host.appendChild(el);

  el.addEventListener('gmp-select', async (event) => {
    const prediction = event.placePrediction || event.detail?.placePrediction;
    if (!prediction) return;
    const place = prediction.toPlace();
    await place.fetchFields({ fields: ['displayName', 'formattedAddress', 'location', 'viewport'] });
    const loc = place.location;
    if (!loc) return;
    const address = place.formattedAddress || place.displayName || '';
    handlePlace({ lat: loc.lat(), lng: loc.lng(), address }, fillAddress);
  });
}

function createLegacyAutocomplete(hostId, inputId, fillAddress) {
  const host = $(hostId);
  host.innerHTML = `<input id="${inputId}" placeholder="${fillAddress ? 'Buscar dirección del reclamo...' : 'Buscar dirección, barrio, plaza...'}" autocomplete="off" />`;
  const input = $(inputId);
  const options = {
    fields: ['formatted_address', 'geometry', 'name'],
    componentRestrictions: window.APP_CONFIG.PLACES_COUNTRY ? { country: window.APP_CONFIG.PLACES_COUNTRY } : undefined
  };
  const autocomplete = new google.maps.places.Autocomplete(input, options);
  autocomplete.addListener('place_changed', () => {
    const place = autocomplete.getPlace();
    if (!place?.geometry?.location) return;
    handlePlace({ lat: place.geometry.location.lat(), lng: place.geometry.location.lng(), address: place.formatted_address || place.name || input.value }, fillAddress);
  });
}

function handlePlace(place, fillAddress) {
  const lat = Number(place.lat), lng = Number(place.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
  map.panTo({ lat, lng });
  map.setZoom(17);
  setSelectedLocation(lat, lng);
  if (fillAddress) $('address').value = place.address || $('address').value;
}

async function loadDamageTypes() {
  const { data, error } = await supabaseClient.from('damage_types').select('*').order('sort_order').order('label');
  if (error) {
    DAMAGE_TYPES = { ...DEFAULT_DAMAGE_TYPES };
    console.warn('No se pudo leer damage_types. Ejecutá database/database.sql.', error.message);
  } else {
    DAMAGE_TYPES = {};
    (data || []).forEach(t => DAMAGE_TYPES[t.key] = { label: t.label, emoji: t.emoji, color: t.color, active: t.active });
    if (!Object.keys(DAMAGE_TYPES).length) DAMAGE_TYPES = { ...DEFAULT_DAMAGE_TYPES };
  }
  renderDamageTypeSelectors();
  renderDamageTypesAdmin();
}

function renderDamageTypeSelectors() {
  const currentType = $('type').value;
  const currentFilter = $('filterType').value || 'all';
  $('type').innerHTML = '';
  $('filterType').innerHTML = '<option value="all">Todos</option>';
  Object.entries(DAMAGE_TYPES).forEach(([key, item]) => {
    const text = `${item.emoji} ${item.label}`;
    if (item.active) $('type').appendChild(new Option(text, key));
    $('filterType').appendChild(new Option(text + (item.active ? '' : ' (inactivo)'), key));
  });
  if (DAMAGE_TYPES[currentType]?.active) $('type').value = currentType;
  $('filterType').value = DAMAGE_TYPES[currentFilter] ? currentFilter : 'all';
}

function setSelectedLocation(lat, lng) {
  $('lat').value = lat.toFixed(7);
  $('lng').value = lng.toFixed(7);
  if (selectedMarker) selectedMarker.setMap(null);
  selectedMarker = new google.maps.Marker({ position: { lat, lng }, map, draggable: true, title: 'Ubicación seleccionada' });
  selectedMarker.addListener('dragend', () => {
    const pos = selectedMarker.getPosition();
    $('lat').value = pos.lat().toFixed(7);
    $('lng').value = pos.lng().toFixed(7);
  });
}

async function loadReports() {
  const { data, error } = await supabaseClient.from('reports').select('*').order('created_at', { ascending: false });
  if (error) return Swal.fire('Error', error.message, 'error');
  allReports = data || [];
  renderMap();
  renderChart();
  renderAdminRows();
}

function filteredReports() {
  const type = $('filterType').value;
  const status = $('filterStatus').value;
  return allReports.filter(r => (type === 'all' || r.type === type) && (status === 'all' || r.status === status));
}

function svgMarker(type) {
  const item = DAMAGE_TYPES[type] || DEFAULT_DAMAGE_TYPES.bache;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="52" height="52" viewBox="0 0 52 52"><circle cx="26" cy="22" r="18" fill="${item.color}" stroke="white" stroke-width="4"/><path d="M26 50 15 35h22L26 50Z" fill="${item.color}" stroke="white" stroke-width="3"/><text x="26" y="30" font-size="22" text-anchor="middle">${item.emoji}</text></svg>`;
  return { url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`, scaledSize: new google.maps.Size(44, 44) };
}

function renderMap() {
  if (!map) return;
  markers.forEach(m => m.setMap(null));
  markers = [];
  filteredReports().forEach(report => {
    const item = DAMAGE_TYPES[report.type] || DEFAULT_DAMAGE_TYPES.bache;
    const marker = new google.maps.Marker({ position: { lat: Number(report.lat), lng: Number(report.lng) }, map, icon: svgMarker(report.type), title: `${item.label} - ${STATUS[report.status]}` });
    const info = new google.maps.InfoWindow({ content: `<div class="info"><strong>${item.emoji} ${item.label}</strong><p>${report.address}</p><p>${report.description}</p><small>Estado: ${STATUS[report.status]}</small></div>` });
    marker.addListener('click', () => info.open({ anchor: marker, map }));
    markers.push(marker);
  });
}

async function submitReport(e) {
  e.preventDefault();
  if (!$('lat').value || !$('lng').value) return Swal.fire('Falta ubicación', 'Seleccioná un punto en el mapa o elegí una dirección de Google Maps.', 'warning');
  const addressValue = $('address').value.trim() || $('addressReference').value.trim();
  if (!addressValue) return Swal.fire('Falta dirección', 'Elegí una dirección desde el buscador de Google Maps o agregá una referencia manual.', 'warning');
  const payload = {
    type: $('type').value,
    name: $('name').value.trim(),
    email: $('email').value.trim(),
    phone: $('phone').value.trim(),
    address: addressValue,
    description: $('description').value.trim(),
    lat: Number($('lat').value),
    lng: Number($('lng').value),
    status: 'pending'
  };
  const { error } = await supabaseClient.from('reports').insert(payload);
  if (error) return Swal.fire('No se pudo enviar', error.message, 'error');
  $('reportForm').reset();
  $('address').value = '';
  if (selectedMarker) selectedMarker.setMap(null);
  Swal.fire('Reclamo enviado', 'Tu solicitud quedó pendiente de aprobación.', 'success');
  await loadReports();
}

function renderChart() {
  const ctx = $('reportsChart');
  if (!ctx) return;
  const counts = Object.fromEntries(Object.keys(DAMAGE_TYPES).map(k => [DAMAGE_TYPES[k].label, 0]));
  filteredReports().forEach(r => {
    const key = DAMAGE_TYPES[r.type]?.label || r.type;
    counts[key] = (counts[key] || 0) + 1;
  });
  if (chart) chart.destroy();
  chart = new Chart(ctx, {
    type: $('chartType').value,
    data: { labels: Object.keys(counts), datasets: [{ label: 'Reclamos', data: Object.values(counts) }] },
    options: { responsive: true, plugins: { legend: { display: true } }, scales: $('chartType').value === 'pie' ? {} : { y: { beginAtZero: true, ticks: { precision: 0 } } } }
  });
}

async function adminLogin() {
  const { error } = await supabaseClient.auth.signInWithPassword({ email: $('adminEmail').value, password: $('adminPassword').value });
  if (error) return Swal.fire('Acceso denegado', error.message, 'error');
  await checkSession();
}

async function checkSession() {
  const { data } = await supabaseClient.auth.getSession();
  const logged = !!data.session;
  $('loginBox').classList.toggle('hidden', logged);
  $('adminBox').classList.toggle('hidden', !logged);
  if (logged) { renderAdminRows(); renderDamageTypesAdmin(); }
}

function renderAdminRows() {
  const tbody = $('adminRows');
  if (!tbody) return;
  tbody.innerHTML = '';
  allReports.forEach(r => {
    const item = DAMAGE_TYPES[r.type] || { emoji: '', label: r.type };
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${new Date(r.created_at).toLocaleString('es-AR')}</td><td>${item.emoji} ${item.label}</td><td>${r.address}</td><td>${r.name}<br><small>${r.email}</small></td><td><span class="badge ${r.status}">${STATUS[r.status]}</span></td><td class="row-actions"><button data-status="approved">Aprobar</button><button data-status="analysis">Analizar</button><button data-status="rejected">Rechazar</button></td>`;
    tr.querySelectorAll('button').forEach(btn => btn.addEventListener('click', () => updateStatus(r.id, btn.dataset.status)));
    tbody.appendChild(tr);
  });
}

async function updateStatus(id, status) {
  const { error } = await supabaseClient.from('reports').update({ status }).eq('id', id);
  if (error) return Swal.fire('Error', error.message, 'error');
  Swal.fire('Actualizado', `Solicitud marcada como: ${STATUS[status]}`, 'success');
  await loadReports();
}

function renderDamageTypesAdmin() {
  const wrap = $('damageTypesRows');
  if (!wrap) return;
  wrap.innerHTML = '';
  Object.entries(DAMAGE_TYPES).forEach(([key, t]) => {
    const card = document.createElement('div');
    card.className = 'type-chip';
    card.innerHTML = `<span class="type-emoji" style="background:${t.color}">${t.emoji}</span><div><strong>${t.label}</strong><small>${key} · ${t.active ? 'activo' : 'inactivo'}</small></div><button class="edit">Editar</button><button class="toggle">${t.active ? 'Desactivar' : 'Activar'}</button>`;
    card.querySelector('.edit').addEventListener('click', () => { $('damageKey').value = key; $('damageKey').readOnly = true; $('damageLabel').value = t.label; $('damageEmoji').value = t.emoji; $('damageColor').value = t.color; $('damageActive').checked = !!t.active; });
    card.querySelector('.toggle').addEventListener('click', () => saveDamageType({ key, label: t.label, emoji: t.emoji, color: t.color, active: !t.active }));
    wrap.appendChild(card);
  });
}

async function saveDamageType(values) {
  const row = { key: values.key, label: values.label, emoji: values.emoji, color: values.color, active: values.active, sort_order: 100 };
  const { error } = await supabaseClient.from('damage_types').upsert(row, { onConflict: 'key' });
  if (error) return Swal.fire('Error', error.message, 'error');
  Swal.fire('Guardado', 'El tipo de daño fue actualizado.', 'success');
  $('damageTypeForm').reset();
  $('damageKey').readOnly = false;
  $('damageColor').value = '#38bdf8';
  $('damageActive').checked = true;
  await loadDamageTypes();
  renderMap();
  renderChart();
}

function bindEvents() {
  $('reportForm').addEventListener('submit', submitReport);
  ['filterType', 'filterStatus'].forEach(id => $(id).addEventListener('input', () => { renderMap(); renderChart(); }));
  $('chartType').addEventListener('change', renderChart);
  $('locateBtn').addEventListener('click', () => navigator.geolocation?.getCurrentPosition(pos => {
    const { latitude, longitude } = pos.coords;
    map.setCenter({ lat: latitude, lng: longitude });
    map.setZoom(17);
    setSelectedLocation(latitude, longitude);
  }, () => Swal.fire('Ubicación', 'No se pudo obtener tu ubicación.', 'warning')));
  $('adminToggleBtn').addEventListener('click', async () => { $('adminDialog').showModal(); await checkSession(); });
  $('closeAdminBtn').addEventListener('click', () => $('adminDialog').close());
  $('loginBox').addEventListener('submit', (e) => { e.preventDefault(); adminLogin(); });
  $('logoutBtn').addEventListener('click', async () => { await supabaseClient.auth.signOut(); await checkSession(); });
  $('refreshAdminBtn').addEventListener('click', async () => { await loadDamageTypes(); await loadReports(); });
  $('damageTypeForm').addEventListener('submit', (e) => { e.preventDefault(); saveDamageType({ key: $('damageKey').value.trim(), label: $('damageLabel').value.trim(), emoji: $('damageEmoji').value.trim(), color: $('damageColor').value, active: $('damageActive').checked }); });
  $('themeToggle').addEventListener('click', toggleTheme);
  $('installBtn').addEventListener('click', async () => { if (deferredPrompt) { deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt = null; $('installBtn').classList.add('hidden'); } });
}

function initRealtime() {
  supabaseClient.channel('public-data')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'reports' }, loadReports)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'damage_types' }, async () => { await loadDamageTypes(); renderMap(); renderChart(); })
    .subscribe();
}

function initTheme() {
  document.documentElement.dataset.theme = localStorage.getItem('theme') || 'dark';
}

function toggleTheme() {
  const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  localStorage.setItem('theme', next);
  if (map) map.setOptions({ styles: next === 'dark' ? darkMapStyle : [] });
}

window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  deferredPrompt = e;
  $('installBtn')?.classList.remove('hidden');
});

const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#1f2937' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#111827' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#d1d5db' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#374151' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0f172a' }] }
];

(async function boot() {
  initTheme();
  initSupabase();
  bindEvents();
  try { await initMap(); } catch (err) { console.error(err); }
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
})();
