// 1) Copiá este proyecto a GitHub Pages.
// 2) Reemplazá estos valores por los tuyos.
// 3) En Supabase ejecutá el SQL del README.md.
window.APP_CONFIG = {
  SUPABASE_URL: 'https://TU-PROYECTO.supabase.co',
  SUPABASE_ANON_KEY: 'TU_SUPABASE_ANON_KEY',
  GOOGLE_MAPS_API_KEY: 'TU_GOOGLE_MAPS_API_KEY',
  MAP_CENTER: { lat: -26.8241, lng: -65.2226 },
  MAP_ZOOM: 13
};
