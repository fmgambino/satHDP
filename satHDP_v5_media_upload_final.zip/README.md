# satHDP v4 — PWA Mapa Interactivo de Reclamos

Versión refactorizada para GitHub Pages con HTML, CSS, JS, Supabase, Google Maps, Places Autocomplete, SweetAlert2 y Chart.js.

## 1) Subir a GitHub Pages

1. Descomprimí el ZIP.
2. Subí todos los archivos al repo `satHDP` reemplazando la versión anterior.
3. En GitHub: **Settings > Pages > Deploy from branch**.
4. Branch: `main`, carpeta `/root`.
5. URL esperada: `https://fmgambino.github.io/satHDP/`.

## 2) Configurar Supabase

En Supabase abrí **SQL Editor** y ejecutá completo:

```sql
/database/database.sql
```

Luego creá el usuario administrador:

1. Supabase > Authentication > Users.
2. Add user.
3. Usá ese email y contraseña en el Panel administrador de la PWA.

## 3) Configurar `config.js`

Reemplazá estos valores:

```js
window.APP_CONFIG = {
  SUPABASE_URL: 'https://TU-PROYECTO.supabase.co',
  SUPABASE_ANON_KEY: 'TU_ANON_KEY',
  GOOGLE_MAPS_API_KEY: 'TU_GOOGLE_MAPS_API_KEY',
  MAP_CENTER: { lat: -26.8241, lng: -65.2226 },
  MAP_ZOOM: 13,
  PLACES_RADIUS_METERS: 30000,
  PLACES_COUNTRY: 'ar'
};
```

## 4) Conectar Google Maps correctamente

En Google Cloud Console:

1. Abrí **APIs & Services > Library**.
2. Activá:
   - **Maps JavaScript API**
   - **Places API**
3. Abrí **APIs & Services > Credentials**.
4. Editá tu API key.
5. En **Application restrictions**, seleccioná **HTTP referrers**.
6. Agregá estos dominios:

```txt
https://fmgambino.github.io/*
https://fmgambino.github.io/satHDP/*
http://localhost:*
```

7. Guardá y esperá 2 a 5 minutos.

Si ves `RefererNotAllowedMapError`, significa que falta autorizar el dominio exacto que Chrome muestra en consola.

## 5) Qué incluye v4

- Mapa Google Maps responsivo.
- Buscador tipo Google Maps con sugerencias en tiempo real.
- Formulario lateral de reclamos.
- Tipos de daño administrables desde el panel.
- Estados: pendiente, análisis, aprobado, rechazado.
- Filtros por tipo y estado.
- Gráficos con Chart.js: torta, barra y línea.
- SweetAlert2 para mensajes.
- PWA instalable.
- Modo oscuro/claro con toggle horizontal.

## Nota importante

El mapa no puede cargar si Google Cloud bloquea el dominio. El código ya está preparado; la API key debe permitir el referer de GitHub Pages.


## v5 - Imágenes y video

Esta versión permite:
- Cargar hasta 5 imágenes por reclamo.
- Validar 5MB máximo por imagen.
- Guardar imágenes en Supabase Storage en el bucket público `report-images`.
- Agregar una URL opcional de video de YouTube, TikTok, Instagram o Facebook.
- Ver imágenes y video desde el mapa y desde el Panel Administrador.

### Actualización de base de datos

Ejecutá nuevamente:

```sql
database/database.sql
```

El script es seguro para instalaciones existentes: agrega `image_urls`, `video_url`, crea el bucket `report-images` y sus policies.

### Supabase Storage

El SQL crea automáticamente el bucket público `report-images`.
Si tu proyecto de Supabase no permite crear buckets desde SQL, hacelo manualmente:

1. Supabase > Storage > New bucket.
2. Nombre: `report-images`.
3. Public bucket: activado.
4. File size limit: `5 MB`.
5. Allowed MIME types: `image/jpeg`, `image/png`, `image/webp`, `image/gif`.

Luego ejecutá las policies incluidas en `database/database.sql`.
